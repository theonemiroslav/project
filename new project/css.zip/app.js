document.addEventListener("DOMContentLoaded", function(event) { 
    var navigation_item = document.querySelector('.navigation_1');
    navigation_item.addEventListener('click', function (e) {
        var target = e.currentTarget;
        var display_value = target.querySelector('.dropdown').style.display;
        console.log(typeof display_value);
        if (!display_value || display_value == 'none') {
            display_value = 'block';
        } else {
            display_value = 'none';
        }
    })
  });